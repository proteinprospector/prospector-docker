#!/usr/bin/perl
use strict;

package main; {

	my $inFName = $ARGV[0];
	my $outFName = $ARGV[1];
	open(INFILE,"<$inFName") || die "cannot read filter file";
	open(OUTFILE,">$outFName" ) || die "cannot create output file";
	my $phase = 1;
	my $pepModCol = 0;
	my $line;
	my $lineEnd = "";
	while ( $line = <INFILE> ) {
		if ( $lineEnd eq "" ) {
			if ( $line =~ /\r/ ) {
				$lineEnd = "\r\n";
			}
			else {
				$lineEnd = "\n";
			}
		}
		$line =~ s/\s+$//;					#remove any white space from end of line
		if ( $phase == 1 ) {									#looking for the header line
			my @columns = &splitCommaNotQuote ( $line );
			my $siz = @columns;
			if ( $line =~ s/Modified Sequence/Modifications/ ) {
				for ( my $i = 0 ; $i < $siz ; $i++ ) {
					if ( $columns [$i] eq "Modified Sequence" ) {
						$pepModCol = $i;
						print OUTFILE $line . $lineEnd;
						$phase = 2;
					}
				} 
			} 
			next;
		}
		if ( $phase == 2 ) {
			my @fields = &splitCommaNotQuote ( $line );
			my $siz = @fields;
			my $mods = &doVariableModString ( $fields [$pepModCol-1], $fields [$pepModCol] );
			chop $mods;
			for ( my $i = 0 ; $i < $siz ; $i++ ) {
				my $f = $fields [$i];
				if ( $i == $pepModCol ) {
					$f = $mods;
				}
				if ( $f =~ /,/ ) {
					print OUTFILE "\"" . $f . "\"";
				}
				else {
					print OUTFILE $f;
				}
				if ( $i != $siz - 1 ) {
					print OUTFILE ",";
				}
			}
			print OUTFILE $lineEnd;
		}
	}
	close INFILE;
	close OUTFILE;

	sub splitCommaNotQuote {
		my ( $line ) = @_;

		my @fields = ();

		while ( $line =~ m/((\")([^\"]*)\"|[^,]*)(,|$)/g ) {
			if ( $2 ) {
				push( @fields, $3 );
			}
			else {
				push( @fields, $1 );
			}
			last if ( ! $4 );
		}
		return @fields;
	}
	sub doVariableModString {
		my ( $pep, $mods ) = @_;
		my @parts = split ( /[<>-]+/, $mods );
		my @delims = split ( /[^<>-]+/, $mods );
		my $off = 0;
		my $pepLen = length $pep;
		my $nterm;
		my $cterm;
		my $curMod;
		my $varModStr = "";
		my $delimIdx = 0;
		for ( my $i = 0 ; $i < @parts ; $i++ ) {
			$delimIdx++;
			my $p = $parts[$i];
			my $len = length $p;
			if ( $off == $pepLen ) {
				$cterm .= $p . $delims[$delimIdx];
				next;
			}
			if ( $p eq substr ( $pep, $off, $len ) ) {	# this is sequence
				$off += $len;
				if ( $nterm ne "" ) {
					chop $nterm;
					if ( $nterm ne "NH2" ) {
						$varModStr .= $nterm . '@N-term;';
					}
					$nterm = "";
				}
				if ( $curMod ne "" ) {
					chop $curMod;
					$varModStr .= $curMod . "@" . ( $off - $len ) . ";";
					$curMod = "";
				}
				next;
			}
			if ( $off == 0 ) {
				$nterm .= $p . $delims[$delimIdx];
			}
			else {
				$curMod .= $p . $delims[$delimIdx];
			}
		}
		if ( $cterm ne "COOH" ) {
			$varModStr .= $cterm . '@C-term;';
		}
		return $varModStr;
	}
}
