source ( "initArgs.R" );
d <- read.table ( dataFileName );
nl <- length ( d );
concat <- nl>1 && is.factor (d[[2]]);
scDat <- if (concat) data.frame ( d [seq(1,nl-1,by=2)] ) else d
catDat <- if (concat) data.frame ( d [seq(2,nl,by=2)] );

xFullRange <- range (scDat, na.rm=TRUE);
xMin <- 10;
xMax <- 60;
xRange <- c(xMin,xMax);
xTickValues <- c(seq(xMin,xMax,by=10));
xLabels <- c(expression ( 10^-1 ),expression ( 10^-2 ),expression ( 10^-3 ),expression ( 10^-4 ),expression ( 10^-5 ), expression ( 10^-6 ));
numSets <- length ( scDat );
yMax <- 0;
for ( i in 1:numSets ) {
	den <- density(na.omit(scDat[[i]]),bw=2,from=xFullRange[1],to=xFullRange[2]);
	yArr <- den$y;
	yArrSplit <- split ( yArr, den$x >= xRange[1] & den$x <= xRange[2] );
	yMax <- max ( yMax, max (yArrSplit$"TRUE") );
}
yRange <- c ( 0, yMax );
numGraphs <- 1;
if ( concat || numSets > 1 ) {
	numGraphs <- 2;
}
imageHeight <- numGraphs * 300;
imageWidth <- 400;
source ( "initGraph.R" );
layout (matrix (c(1:numGraphs),ncol=1));
for ( j in 1:numSets ) {
	den <- density(na.omit(scDat[[j]]),bw=2,from=xFullRange[1],to=xFullRange[2]);
	if ( j == 1 ) {
		plot (den,xlim=xRange,ylim=yRange,main="",ann=FALSE,axes=FALSE);
	}
	else {
		par (new=TRUE);
		plot (den,xlim=xRange,ylim=yRange,ann=FALSE,axes=FALSE,col=j);
	}
}
box ();
axis ( 1,at=xTickValues,labels=xLabels );
axis ( 2 );
title (xlab='Expectation Value',ylab='Density');
if ( concat || numSets > 1 ) {
	yLabels <- c("10","1","0.1","0.01","0.001");
	if ( concat ) {
		for ( i in 1:numSets ) {
			scDatSplit <- split ( scDat[[i]], catDat[[i]] );
			den1 <- density(na.omit(scDatSplit$"N"),bw=2,from=xFullRange[1],to=xFullRange[2]);
			revX <- rev (den1$x);
			xInt <- revX[1]-revX[2];
			cumY1 <- cumsum ( rev (den1$y) * xInt * den1$n);
			den2 <- density(na.omit(scDatSplit$"D"),bw=2,from=xFullRange[1],to=xFullRange[2]);
			cumY2 <- cumsum ( rev (den2$y) * xInt * den2$n );
			if ( i > 1 ) {
				par (new=TRUE);
			}
			plot (revX,200.0*cumY2/(cumY2+cumY1), type="l",xlim=xRange,ylim=c(0.001,10),log="y", col=i,ann=FALSE, axes=FALSE);
		}
	}
	else {
		den1 <- density(na.omit(scDat[[1]]),bw=2,from=xFullRange[1],to=xFullRange[2]);
		revX <- rev (den1$x);
		xInt <- revX[1]-revX[2];
		cumY1 <- cumsum ( rev (den1$y) * xInt * den1$n);
		for ( j in 2:numSets ) {
			den <- density(na.omit(scDat[[j]]),bw=2,from=xFullRange[1],to=xFullRange[2]);
			cumYN <- cumsum ( rev (den$y) * xInt * den$n );
			if ( j > 2 ) {
				par (new=TRUE);
			}
			plot (revX,100.0*cumYN/(cumYN+cumY1), type="l",xlim=xRange,ylim=c(0.001,10),log="y", col=j,ann=FALSE, axes=FALSE);
		}
	}
	box ();
	axis ( 1,at=xTickValues,labels=xLabels );
	axis ( 2,at=c(10,1,0.1,0.01,0.001),labels=yLabels );
	title (xlab='Expectation Value',ylab='% False Positive');
}
