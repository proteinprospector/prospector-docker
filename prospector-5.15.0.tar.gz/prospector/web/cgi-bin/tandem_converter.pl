#!/usr/bin/perl
use strict;

my $inFName = $ARGV[0];
my $outFName = $ARGV[1];
open(INFILE,"<$inFName") || die "cannot read filter file";
open(OUTFILE,">$outFName" ) || die "cannot create output file";
my $phase = 1;
my $pepModCol = 0;
my $startCol = 0;
my $line;
while ( $line = <INFILE> ) {
	my @columns = split ( "\t", $line );
	my $siz = @columns;
	if ( $columns [0] eq "Spectrum" ) {					#this is the header line
		for ( my $i = 0 ; $i < $siz ; $i++ ) {
			if ( $columns [$i] eq "start" ) {
				$startCol = $i;
			}
			elsif ( $columns [$i] eq "modifications" ) {
				$pepModCol = $i;
				last;
			}
		} 
		print OUTFILE $line;
		$phase = 2;
		next;
	}
	if ( $phase == 2 ) {
		my $mod = $columns [$pepModCol];
		my $oMod;
		if ( $mod !~ /^\s*$/ ) {				# If the mod is not blank 
			my $start = $columns [$startCol];
			my @singMods = split ( ",", $mod );
			foreach ( @singMods ) {
				if ( /\[(\d+)\] ([+-]?(\d+\.\d+|\d+\.|\.\d+))/ ) {
					$oMod .= $2;
					$oMod .= '@';
					$oMod .= $1 - $start + 1;
					$oMod .= ';';
				}
			}
			chop $oMod;							#delete last semi colon
		}
		for ( my $i = 0 ; $i < $siz ; $i++ ) {
			my $f = $columns [$i];
			if ( $i == $pepModCol ) {
				$f = $oMod;
			}
			print OUTFILE $f;
			if ( $i != $siz - 1 ) {
				print OUTFILE "\t";
			}
		}
	}
}
close INFILE;
close OUTFILE;
