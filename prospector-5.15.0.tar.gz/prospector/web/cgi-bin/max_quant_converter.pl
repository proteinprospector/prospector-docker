#!/usr/bin/perl
use strict;

package AmbiguousMods; {
	my $numSites;
	my @sites;
	my @sequence;
	my $aMods;

	sub new {
		my ( $probStr, $type, $probLimit ) = @_;
		@sites=();
		@sequence=();
		$aMods = "";
		if ( $probStr !~ /^\s*$/ ) {				# If the string is not blank
			my $offset = 0;
			my $totalProb = 0;
			while ( $probStr =~ /(\(.+?\))/g ) {
				my $prob = $1;
				chop $prob;							# Strip last character
				substr $prob, 0, 1, "";				# Strip first character
				$totalProb += $prob;
				my $pos = $-[0] - $offset;
				if ( $prob > 1.0 - $probLimit ) {
					if ( $aMods eq "" ) {					
						$aMods .= $type;
						$aMods .= '@';
					}
					else {
						$aMods .= '&';
					}
					$aMods .= $pos;
					$totalProb -= 1;
				}
				elsif ( $prob > $probLimit ) {
					push ( @sites, $pos );
				}
				$offset += $+[0] - $-[0];
			}
			if ( $aMods ne "" ) {					
				$aMods .= ';';
			}
			$numSites = int ( $totalProb + 0.5 );
			if ( $numSites == 0 ) {
				return $aMods;
			}
			$aMods .= $type;
			$aMods .= '@';
			if ( $numSites == @sites ) {
				foreach my $s (@sites) {
					$aMods .= $s;
					$aMods .= '&';
				}
			}
			else {
				&getNext ( 0 );
			}
			chop $aMods;
			$aMods .= ';';
		}
		return $aMods;
	}
	sub getNext {
		my ( $level ) = @_;
		for ( my $i = $level ; $i < @sites ; $i++ ) {
			push ( @sequence, $sites [$i] );
			if ( @sequence < $numSites ) {
				$level += 1;
				&getNext ( $level );
			}
			else {
				for my $s (@sequence) {
					$aMods .= $s;
					$aMods .= '&';
				}
				chop $aMods;
				$aMods .= '|';
			}
			pop ( @sequence );
		}
	}
}

package main; {
	my $nargs = @ARGV;
	my $filterType;
	my $inFName;
	my $outFName;
	my $probLimit;
#my @silacAA = ( "K", "R" );
#my @silacAA = ( "K" );
	my @silacAA = ();
	my $silacAAs;
	foreach ( @silacAA ) {
		$silacAAs .= "|" . $_;
	}
	my $silacRE = "(\\(.+?\\)" . $silacAAs . ")";
	my $silacRegExp = qr /$silacRE/;
	my %silac = (
		#K1 => 'Label:13C(6)15N(2)@',

		#K1 => 'Label:2H(4)@',
		#K2 => 'Label:13C(6)15N(2)@',
		#R1 => 'Label:13C(6)@',
		#R2 => 'Label:13C(6)15N(4)@'
	);
	if ( $nargs == 3 ) {
		$inFName = $ARGV[0];
		$outFName = $ARGV[1];
		$probLimit = $ARGV[2];
	}
	else {
		$inFName = $ARGV[0];
		$outFName = $ARGV[1];
		$probLimit = $ARGV[2];
		$filterType = $ARGV[3];
	}
	open(INFILE,"<$inFName") || die "cannot read filter file";
	open(OUTFILE,">$outFName" ) || die "cannot create output file";
	my $phase = 1;
	my $modSeqCol = 0;
	my $fragCol = 0;
	my $silacCol = 0;

	my $oxProbCol = 0;
	my $phProbCol = 0;
	my $caProbCol = 0;
	my $coProbCol = 0;
	my $acProbCol = 0;

	my $line;
	my @columns;

	while ( $line = <INFILE> ) {
		@columns = split ( "\t", $line );
		my $siz = @columns;
		my $flag = 0;
		for ( my $i = 0 ; $i < $siz ; $i++ ) {
			if ( uc($columns [$i]) eq uc("Raw File") ) {
				$flag = 1;
				last;
			}
		}
		if ( $flag == 1 ) {					#this is the header line
			for ( my $j = 0 ; $j < $siz ; $j++ ) {
				if ( uc($columns [$j]) eq uc("Modified sequence") ) {
					$modSeqCol = $j;
				}
				elsif ( uc($columns [$j]) eq uc("Oxidation (M) Probabilities") ) {
					$oxProbCol = $j;
				}
				elsif ( uc($columns [$j]) eq uc("Phospho (STY) Probabilities") ) {
					$phProbCol = $j;
				}
				elsif ( uc($columns [$j]) eq uc("Carbamidomethyl (C) Probabilities") ) {
					$caProbCol = $j;
				}
				elsif ( uc($columns [$j]) eq uc("Copy of Lys8 Probabilities") ) {
					$coProbCol = $j;
				}
				elsif ( uc($columns [$j]) eq uc("Acetyl (K) Probabilities") ) {
					$acProbCol = $j;
				}
				elsif ( uc($columns [$j]) eq uc("Fragmentation") ) {
					$fragCol = $j;
				}
				elsif ( uc($columns [$j]) eq uc("Labeling State") ) {
					$silacCol = $j;
					last;
				}
			}
			$line =~ s/Modified sequence/Variable mods/i;
			if ( $filterType ne "" ) {
				$line =~ s/Fragmentation\t//i;			#delete Fragmentation column (i - ignore case)
			}
			print OUTFILE $line;
			$phase = 2;
			next;
		}
		if ( $phase == 2 ) {						# example _(ac)AAAAAAAGDSDS(ph)WDADAFSVEDPVR_
			my $oMod = &getModificationString ( $columns [$modSeqCol], $columns [$silacCol] );
			if ( $filterType ne "" ) {
				my $fragmentation = $columns [$fragCol];
				if ( $fragmentation eq $filterType ) {	# only include rows of the correct fragmentation type
					for ( my $i = 0 ; $i < $siz ; $i++ ) {
						my $f = $columns [$i];
						if ( $i == $modSeqCol ) {
							$f = $oMod;
						}
						if ( $i != $fragCol ) {			# don't output the fragmentation column
							print OUTFILE $f;
							if ( $i != $siz - 1 ) {
								print OUTFILE "\t";
							}
						}
					}
				}
			}
			else {
				for ( my $i = 0 ; $i < $siz ; $i++ ) {
					my $f = $columns [$i];
					if ( $i == $modSeqCol ) {
						$f = $oMod;
					}
					print OUTFILE $f;
					if ( $i != $siz - 1 ) {
						print OUTFILE "\t";
					}
				}
			}
		}
	}
	close INFILE;
	close OUTFILE;

	sub getModificationString {
		my ( $mod, $label ) = @_;
		my $oMod;
		my $offset = 0;
		if ( $mod !~ /^\s*$/ ) {				# If the mod is not blank
			$mod = substr ( $mod, 1 );			# delete first character
			chop $mod;					# delete last character
			while ( $mod =~ /$silacRegExp/g ) {		# ? means non-greedy otherwise can match (ac)AAAAAAAGDSDS(ph)
				if ( $1 eq "(ac)" ) {
					if ( $-[0] == 0 ) {
						$oMod .= "Acetyl@";
						$oMod .= "N-term";
						$oMod .= ';';
					}
					else {
						if ( $probLimit >= 1 ) {
							$oMod .= "Acetyl@";
							$oMod .= $-[0] - $offset;
							$oMod .= ';';
						}
					}
					$offset += $+[0] - $-[0];
				}
				elsif ( $1 eq "(ph)" ) {
					if ( $probLimit >= 1 ) {
						$oMod .= "Phospho@";
						$oMod .= $-[0] - $offset;
						$oMod .= ';';
					}
					$offset += $+[0] - $-[0];
				}
				elsif ( $1 eq "(ca)" ) {
					if ( $probLimit >= 1 ) {
						$oMod .= "Carbamidomethyl@";
						$oMod .= $-[0] - $offset;
						$oMod .= ';';
					}
					$offset += $+[0] - $-[0];
				}
				elsif ( $1 eq "(ox)" ) {
					if ( $probLimit >= 1 ) {
						$oMod .= "Oxidation@";
						$oMod .= $-[0] - $offset;
						$oMod .= ';';
					}
					$offset += $+[0] - $-[0];
				}
				elsif ( $1 eq "(gl)" ) {
					$oMod .= "Gln->pyro-Glu@" . "N-term";
					$offset += $+[0] - $-[0];
					$oMod .= ';';
				}
				elsif ( $1 eq "(co)" ) {
					if ( $probLimit >= 1 ) {
						$oMod .= "Label:13C(6)15N(2)@";
						$oMod .= $-[0] - $offset;
						$oMod .= ';';
					}
					$offset += $+[0] - $-[0];
				}
				else {
					foreach ( @silacAA ) {
						my $aa = $_;
						if ( $1 eq $aa ) {
							if ( $label eq "1" ) {
								$oMod .= $silac { $aa . "1" };
								$oMod .= $-[0] - $offset + 1;
								$oMod .= ';';
							}
							elsif ( $label eq "2" ) {
								$oMod .= $silac { $aa . "2" };
								$oMod .= $-[0] - $offset + 1;
								$oMod .= ';';
							}
							last;
						}
					}
				}
			}
			if ( $probLimit < 1.0 ) {
				if ( $oxProbCol && length $columns [$oxProbCol] ) {
					$oMod .= AmbiguousMods::new ( $columns [$oxProbCol], "Oxidation", $probLimit );
				}
				if ( $phProbCol && length $columns [$phProbCol] ) {
					$oMod .= AmbiguousMods::new ( $columns [$phProbCol], "Phospho", $probLimit );
				}
				if ( $caProbCol && length $columns [$caProbCol] ) {
					$oMod .= AmbiguousMods::new ( $columns [$caProbCol], "Carbamidomethyl", $probLimit );
				}
				if ( $coProbCol && length $columns [$coProbCol] ) {
					$oMod .= AmbiguousMods::new ( $columns [$coProbCol], "Label:13C(6)15N(2)", $probLimit );
				}
				if ( $acProbCol && length $columns [$acProbCol] ) {
					$oMod .= AmbiguousMods::new ( $columns [$acProbCol], "Acetyl", $probLimit );
				}
			}
			chop $oMod;
		}
		return $oMod;
	}
}
