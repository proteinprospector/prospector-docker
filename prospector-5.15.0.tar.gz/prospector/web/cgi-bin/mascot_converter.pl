#!/usr/bin/perl
use strict;

package Modification; {

	sub new {
		my $class = shift();
		my $self = {};
		bless $self, $class;
		my ( $v1, $v2, $v3 ) = @_;
		$self->{mod} = $v1;
		$self->{res} = $v2;
		$self->{term} = $v3;
		return $self;
	}
}

package main; {

	my $inFName = $ARGV[0];
	my $outFName = $ARGV[1];
	open(INFILE,"<$inFName") || die "cannot read filter file";
	open(OUTFILE,">$outFName" ) || die "cannot create output file";
	my $phase = 0;
	my $pepSeqCol = 0;
	my $pepModCol = 0;
	my %constMod = ();
	my %varMod = ();
	my $line;
	my $lineEnd = "";
	while ( $line = <INFILE> ) {
		if ( $lineEnd eq "" ) {
			if ( $line =~ /\r/ ) {
				$lineEnd = "\r\n";
			}
			else {
				$lineEnd = "\n";
			}
		}
		$line =~ s/\s+$//;					#remove any white space from end of line
		if ( $line =~ /^\"*Fixed modifications\"*/ ) {
			$phase = 1;
			next;
		}
		if ( $line =~ /^\"*Variable modifications\"*/ ) {
			$phase = 2;
			next;
		}
		if ( $line =~ /^\"*Protein hits\"*/ ) {
			$phase = 3;
			next;
		}
		if ( $phase == 1 ) {		#define the constant modifications
			if ( $line =~ /^(\d+),(.+) \((.+)\),([+-]?(\d+\.\d+|\d+\.|\.\d+))/ ) {
				$constMod{$1} = &addModification ( $2, $3 );
			}
		}
		elsif ( $phase == 2 ) {		#define the variable modifications
			if ( $line =~ /^(\d+),\"*(.+) \((.+)\)\"*,([+-]?(\d+\.\d+|\d+\.|\.\d+))/ ) {
				$varMod{$1} = &addModification ( $2, $3 );
			}
		}
		elsif ( $phase == 3 ) {		#modify the column headers
			if ( $line =~ s/pep_var_mod,pep_var_mod_pos/pep_mod/ ) {
				my @headers = &splitCommaNotQuote ( $line );
				my $size = @headers;
				for ( my $i = 0 ; $i < $size ; $i++ ) {
					if ( $headers [$i] eq "pep_seq" ) {
						$pepSeqCol = $i;
					}
					if ( $headers [$i] eq "pep_mod" ) {
						$pepModCol = $i;
						last;
					}
				}
				print OUTFILE $line . $lineEnd;
				$phase = 4;
			}
		}
		elsif ( $phase == 4 ) {
			my @fields = &splitCommaNotQuote ( $line );
			my $siz = @fields;
			my $mods = &doConstModString ( $fields [$pepSeqCol] ) . &doVariableModString ( $fields [$pepModCol+1] );
			chop $mods;				#get rid of last semi colon
			for ( my $i = 0 ; $i < $siz ; $i++ ) {
				my $f = $fields [$i];
				if ( $i == $pepModCol ) {
					$f = $mods;
					$i++;					#mods are now in a single column
				}
				if ( $f =~ /,/ ) {
					print OUTFILE "\"" . $f . "\"";
				}
				else {
					print OUTFILE $f;
				}
				if ( $i != $siz - 1 ) {
					print OUTFILE ",";
				}
			}
			print OUTFILE $lineEnd;
		}
	}
	close INFILE;
	close OUTFILE;

	sub addModification {
		my ( $mod, $res ) = @_;
		my $term = "";
		if ( $res =~ /C-term(.*)$/ ) {
			if ( $1 eq "" ) {
				$res = "";
				$term = "c";
			}
			else {
				$res = substr $1, 1;
			}
		}
		elsif ( $res =~ /N-term(.*)$/ ) {
			if ( $1 eq "" ) {
				$res = "";
				$term = "n";
			}
			else {
				$res = substr $1, 1;
			}
		}
		return new Modification ( $mod, $res, $term );
	}
	sub splitCommaNotQuote {
		my ( $line ) = @_;

		my @fields = ();

		while ( $line =~ m/((\")([^\"]*)\"|[^,]*)(,|$)/g ) {
			if ( $2 ) {
				push( @fields, $3 );
			}
			else {
				push( @fields, $1 );
			}
			last if ( ! $4 );
		}
		return @fields;
	}
	sub doConstModString {
		my ( $peptide ) = @_;

		my $constModStr = "";

		for my $key ( keys %constMod ) {
			my $cMod = $constMod{$key};
			my $mod = $cMod->{mod};
			my $res = $cMod->{res};
			my $term = $cMod->{term};
			if ( $term eq "n" ) {
				$constModStr .= $mod . '@N-term;';
			}
			elsif ( $term eq "c" ) {
				$constModStr .= $mod . '@C-term;';
			}
			else {
				my $i;
				my $len = length $res;
				for ( $i = 0 ; $i < $len ; $i++ ) {
					my $aa = substr $res, $i, 1;
					my $idx = 0;
					while ( 1 ) {
						$idx = index ( $peptide, $aa, $idx );
						if ( $idx == -1 ) {
							last;
						}
						$constModStr .= $mod . "@" . ( $idx + 1 ) . ";";
						$idx += 1;
					}
				}
			}
		}
		return $constModStr;
	}
	sub doVariableModString {
		my ( $mask ) = @_;
		my $len = length $mask;

		my $varModStr = "";
		if ( $len > 0 ) {
			my $nterm = substr $mask, 0, 1;
			if ( $nterm ne "0" ) {
				if ( $varMod {$nterm}->{res} eq "" ) {
					$varModStr .= $varMod {$nterm}->{mod} . '@N-term;';
				}
				else {
					$varModStr .= $varMod {$nterm}->{mod} . '@1;';
				}
			}
			for ( my $i = 2 ; $i < $len - 2 ; $i++ ) {
				my $aa = substr $mask, $i, 1;
				if ( $aa ne "0" ) {
					$varModStr .= $varMod {$aa}->{mod} . "@" . ( $i - 1 ) . ";";
				}
			}
			my $cterm = substr $mask, $len - 1;
			if ( $cterm ne "0" ) {
				if ( $varMod {$cterm}->{res} eq "" ) {
					$varModStr .= $varMod {$cterm}->{mod} . '@C-term;';
				}
				else {
					$varModStr .= $varMod {$cterm}->{mod} . "@" . ( $len - 4 ) . ";";
				}
			}
		}
		return $varModStr;
	}
}
