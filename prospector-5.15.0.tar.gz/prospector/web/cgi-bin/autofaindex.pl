#!/usr/bin/perl
##################################################################################
#
#  Filename   : autofaindex.pl
#
#  Created    : Mar 30th 2000
#
#  Purpose    : To automatically download uncompress and index databases
# 		from remote ftp servers.
# 		by Richard Jacob & Peter Baker.
#
#  Author(s)  : Richard Jacob & Peter Baker
#
#  This file is the confidential and proprietary product of The Regents of
#  the University of California.
#
#  Copyright (2000-2015) The Regents of the University of California.
#
#  All rights reserved.
#
##################################################################################

use strict;
use LWP::Simple;
use Net::FTP;
use Compress::Zlib;
use Cwd;

my $version = "3.0";
my $cwd = getcwd;

my $osname = $^O;

{
	my @fastaDatabaseList  = @ARGV;
	my $seqdb = &getSeqdb ();
	print "Starting to update databases\n\n";
	my ( @remoteFileCompressedSizeList ) = &checkAvailableDiskSpace ( @fastaDatabaseList );
	my $i = 0;
	foreach my $fastaDatabase ( @fastaDatabaseList ) {
		my ( $user, $password, $compressionFactor, $decoy, @urlList ) = &getDatabaseParams ( $fastaDatabase );
		my @filenameList;
		foreach my $url ( @urlList ) {
			my ( $host, $path, $filename ) = &getURLElements ( $url );
			chdir $seqdb;
			my $fileSize = &getRemoteFile ( $user, $password, $host, $path, $filename );
			if ( $fileSize != $remoteFileCompressedSizeList [$i] ) {
				unlink ( $filename );
				errorHandler ( "File transfer incomplete\nDeleting transferred file\n" );
			}
			my ( $f ) = &uncompressFile ( $filename, $fileSize );
			push ( @filenameList, $f );
			$i++;
		}
		my $prospectorFilename = &joinFiles ( $fastaDatabase, @filenameList );
		&runFAIndex ( $prospectorFilename, $decoy, $seqdb );
	}
	print "Finished updating databases\n";
}

sub checkAvailableDiskSpace {

	my ( @fastaDatabaseList ) = @_;

	my $seqdb = &getSeqdb ();
	my @remoteFileCompressedSizeList;		# size of individual files
	my $totalEstRemoteFileSize = 0;
	foreach my $fastaDatabase ( @fastaDatabaseList ) {
		my ( $user, $password, $compressionFactor, $decoy, @urlList ) = &getDatabaseParams ( $fastaDatabase );
		unless ( $user ) {
			errorHandler ( "Can't find the database type $fastaDatabase in dbhosts.txt\n" );
		}
		chdir $seqdb;
		my $estRemoteFileSize = 0;
		foreach my $url ( @urlList ) {
			my ( $host, $path, $filename ) = &getURLElements ( $url );
			my ( $remoteFileCompressedSize ) = &getRemoteFileSize ( $user, $password, $host, $path, $filename );

			push ( @remoteFileCompressedSizeList, $remoteFileCompressedSize );
			my $currentFileSizeEstimate = $remoteFileCompressedSize / $compressionFactor;
			if ( $decoy =~ /Random/ ) {
				$currentFileSizeEstimate += $currentFileSizeEstimate;
			}
			if ( $decoy =~ /Reverse/ ) {
				$currentFileSizeEstimate += $currentFileSizeEstimate;
			}
			$estRemoteFileSize += $currentFileSizeEstimate;
		}
		if ( $decoy !~ /Reverse/ && $decoy !~ /Random/ && @urlList > 1 ) {	# Allow for concatenation
			$estRemoteFileSize *= 2;
		}
		printFileSize ( "Estimated uncompressed database size for $fastaDatabase = ", $estRemoteFileSize );
		$totalEstRemoteFileSize += $estRemoteFileSize;
	}
	$totalEstRemoteFileSize *= 1.2;			# allow for index files
	printFileSize ( "Total estimated disk space required for all databases = ", $totalEstRemoteFileSize );
	my $diskFreeSpace = &getDiskFreeSpace ();
	if ( $diskFreeSpace <= $totalEstRemoteFileSize ) {
		errorHandler ( "Insufficient disk space to update databases.\n" );
	}
	return ( @remoteFileCompressedSizeList );
}

sub getURLElements {
	my ( $url ) = @_;
	my ( $host, $full_path ) = split /\//, $url, 2;
	my ( @pathElements, $path, $filename );
	@pathElements = split /\//, $full_path;
	$path = join "\/", @pathElements [0..($#pathElements-1)];
	$filename = $pathElements [$#pathElements];
	return ( $host, $path, $filename );
}

sub getDatabaseParams {
	my ( $fastaDatabase ) = @_;
	my ( @url, $user, $password, $compressionFactor, $decoy );
	my $line;
	chdir ( $cwd ) || die "cannot change directory ($!)";
	if ( open ( FILE, "../params/dbhosts.txt" ) == 0 ) {	
		errorHandler ( "Can't find the database configuration file dbhosts.txt" );
	}
	while ( $line = <FILE> ) {
		if ( $line =~ /^#/ ) {
			next;
		}
		if ( $line =~ /^$fastaDatabase$/ ) {
			my $temp;
			while ( 1 ) {
				chop ( $temp = <FILE> );
				if ( $temp =~ /^ftp/ ) {
					push ( @url, $temp );
				}
				else {
					last;
				}
			}
			$user = $temp;
			chop ( $password = <FILE> );
			chop ( $compressionFactor = <FILE> );
			chop ( $decoy = <FILE> );
			last;
		}
	}
	close FILE;
	return ( $user, $password, $compressionFactor, $decoy, @url );
}

sub getSeqdb {
	chdir ( $cwd ) || die "cannot change directory ($!)";
	if ( open ( INFO, "../params/info.txt" ) == 0 ) {	
		errorHandler ( "Can't find the configuration file info.txt" );
	}
	my $seqdb;
	while ( my $locline = <INFO> ) {
		if ( $locline =~ /^#/ ) {					# ignore comment lines
			next;
		}
		if ( $locline =~ /^seqdb/ ) {
			my $sublen = 5;							# this is the default value
			if ( $locline =~ /^seqdb_unix/ ) {
				if ( $osname ne "linux" ) {			# ignore the directive if this is windows
					next;
				}
				$sublen = 10;
			}
			elsif ( $locline =~ /^seqdb_win/ ) {
				if ( $osname eq "linux" ) {			# ignore the directive if this is linux
					next;
				}
				$sublen = 9;
			}
			$seqdb = substr $locline, $sublen;
			$seqdb =~ s/^\s+//;				# remove leading space
			$seqdb =~ s/\s+$//;				# remove trailing space
			last;
		}
	}
	close INFO;
	return ( $seqdb );
}

sub getDiskFreeSpace {
	my $size;
	my $tempFilename = "t_$$.txt";
	my $rc;
	if ( $osname eq "linux" ) {
		$rc = system "df . | grep -v '^Filesystem' | grep '%' | awk 'NF==6{print \$4}NF==5{print \$3}{}' > $tempFilename";
	}
	else {
		$rc = system "dir > $tempFilename";
	}
	if ( $rc ) {
		errorHandler ( "system call to find disk free space failed.\n" );
	}
	my ( $line, @fields );

	if ( open ( FILE, $tempFilename ) == 0 ) {
		errorHandler ( "Problems opening the file $tempFilename" );
	}
	while ( $line = <FILE> ) {
		if ( $osname eq "linux" ) {
			$size = $line * 1024;
		}
		else {
			if ( $line =~ /bytes free/ ) {
				@fields = split /\s+/, $line;
				$size = join "", split(/\,/, $fields[3]);
				last;
			}
		}
	}
	close FILE;
	unlink $tempFilename;
	printFileSize ( "Free disk space = ", $size );
	return ( $size );
}

sub getRemoteFileSize {
	my ( $user, $password, $host, $path, $filename) = @_;
	my $tempFilename1 = "t1_$$.txt";
	my $tempFilename2 = "t2_$$.txt";
	my ( $line, @fields, $size, $ftp, @lines, @filesize );

	print "Getting remote file name and size\n";

	if ( substr ( $host, 0, 1 ) eq "s" ) {
		$ftp = Net::SFTP->new ( $host );
	}
	else {
		$ftp = Net::FTP->new ( $host );
	}
	$ftp->login ( "$user"," $password" );
	@lines = $ftp->dir("$path");
	@filesize = $ftp->size("$filename");
	$ftp->quit;

	if ( open ( FILE, ">$tempFilename2" ) == 0 ) {
		errorHandler ( "Problems creating the file $tempFilename2\n" );
	}
	foreach $line (@lines){
		print FILE "$line\n";
	}
	close FILE;
	if ( open ( FILE, $tempFilename2 ) == 0 ) {
		unlink ( $tempFilename1 );
		errorHandler ( "Problems opening the file $tempFilename2\n" );
	}
	while ( $line = <FILE> ) {
		@fields = split ' ', $line;
		if ( $fields[$#fields] eq $filename ) {
			$size = $fields[$#fields-4];
		}
	}
	close FILE;
	unlink ( $tempFilename2 );
	if ( $size == 0 ) {
		errorHandler ( "Database file $filename not found on $host.\n" );
	}
	printFileSize ( "Database file name is $filename, size (compressed) = ", $size );
	return ( $size );
}

sub getRemoteFile {
	my ( $user, $password, $host, $path, $filename ) = @_;
	my ($ftp, $passive, $type, $hash);

	print "\nDownloading database file $filename\n";
	$passive = "Passive";
	$hash= "Hash";
	if ( substr ( $host, 0, 1 ) eq "s" ) {
		$ftp = Net::SFTP->new ( $host );
	}
	else {
		$ftp = Net::FTP->new ( $host, $passive, $hash );
	}
	$ftp->login("$user"," $password");
	$ftp->cwd("$path");
	$ftp->binary();
	$ftp->get("$filename");
	$ftp->quit;

	my $fileSize = -s $filename;

	print "File download completed.\n\n";
	printFileSize ( "Compressed database file size = ", $fileSize );

	return ( $fileSize );
}

sub uncompressFile {
	my ( $filename, $compSize ) = @_;
	print "Uncompressing file\n";
	my $tempFilename = substr $filename, 0, -3;
	my $buffer;
	open ( GZIPFILE, ">:raw", $tempFilename );
	my $gz = gzopen ( $filename, "rb" ) 
		or die "Cannot open $filename: $gzerrno\n";
		print GZIPFILE $buffer 
			while $gz->gzread ( $buffer ) > 0;
		die "Error reading from $tempFilename: $gzerrno\n" 
			if $gzerrno != Z_STREAM_END;
	$gz->gzclose ();
	close GZIPFILE;
	unlink ( $filename );

	my $fileSize = -s $tempFilename;
	print "Uncompression completed\n";
	printFileSize ( "Uncompressed file size = ", $fileSize );
	printf ( "Compression ratio = %.2f\n", $compSize / $fileSize );
	return ( $tempFilename );
}

sub joinFiles {
	my ( $prospectorName, @filenameList ) = @_;

	my @localtime = localtime;
	my $dbName = $prospectorName.'.'.($localtime[5]+1900).'.'.($localtime[4]+1).'.'.$localtime[3];
	my $newFilename = $dbName.".fasta";

	if ( @filenameList == 1 ) {
		rename ( $filenameList [0], $newFilename );
	}
	else {
		print ( "Creating concatenated file $newFilename\n" );
		if ( $osname eq "linux" ) {
			my $mycommandline = "cat ";
			foreach my $filename ( @filenameList ) {
				$mycommandline .= $filename;
				$mycommandline .= " ";
			}
			$mycommandline .= "> $newFilename";
			my $rc = system ( "$mycommandline" );
			if ( $rc ) {
				foreach my $filename ( @filenameList ) {
					unlink ( $filename );
				}
				errorHandler ( "cat commanf did not correctly execute correctly\n.Deleting transferred files.\n" );
			}
		}
		else {									# Windows
			open ( OUT, ">:raw", $newFilename );
			foreach my $filename ( @filenameList ) {
				print ( "Adding file $filename\n" );
				open ( IN, "<:raw", $filename );
				print OUT $_ 
					while <IN>;
				close IN;
			}
			close OUT;
		}
		print ( "Concatenation complete\n" );
		foreach my $filename ( @filenameList ) {
			unlink ( $filename );
		}
	}
	return ( $dbName );
}

sub runFAIndex {
	my ($filename, $decoy, $seqdb) = @_;

	chdir ( $cwd ) || die "cannot change directory ($!)";

	&runFAIndexCommand ( $filename, "Normal" );
	if ( $decoy =~ /Random/ ) {
		&runFAIndexCommand ( $filename, "Random" );
	}
	if ( $decoy =~ /Reverse/ ) {
		&runFAIndexCommand ( $filename, "Reverse" );
	}

	chdir ( $seqdb ) || die "cannot change directory ($!)";
	print "The database $filename has been indexed\n";
}

sub runFAIndexCommand {
	my ($filename,$decoy) = @_;
	my $tempFilename = "fa_$$.txt";
	my $mycommandline = "faindex.cgi";

	print "Issuing FA-Index command for $filename\n";
	if ( $osname eq "linux" ) {
		$mycommandline = "./faindex.cgi"
	}
	$mycommandline .= " - create_database_indicies=1";
	if ( $decoy eq "Random" ) {
		$mycommandline .= " random_database=1";
		print "Random flag\n";
	}
	elsif ( $decoy eq "Reverse" ) {
		$mycommandline .= " reverse_database=1";
		print "Reverse flag\n";
	}
	$mycommandline .= " database=" . $filename . " > " . $tempFilename;
	my $rc = system ( "$mycommandline" );
	if ( $rc ) {
		print "Command line = $mycommandline\n";
		print "Error Code = $rc\n";
		errorHandler ( "FAIndex did not correctly execute\n" );
	}
	my ($success) = &docchecker ( $tempFilename );		 
	&successchecker ( $success );
}

sub docchecker {
	my ( $tempFilename ) = @_;
	my $success = 2;
	my $success_text = "Indexed Database";
	my $error_text = "Error Message";
	my $line;
	open ( FAINDEXOUT, $tempFilename ) || die "Temp file from faindex could not be found\n"; 
	while ( <FAINDEXOUT> ) {
		$line = $_;	
		if ( $line =~ /$success_text/ ) {
			$success = 1;
		}
		elsif ( $line =~ /$error_text/ ) {
			$success = 0;
		}
	}
	close ( FAINDEXOUT ) || die "Can't close $tempFilename!";
	unlink ( $tempFilename );
	return ( $success );
}

sub successchecker {
	my ($success ) = @_;
	if ( $success == 0 ) {
		errorHandler ( "Error by FAIndex, did not correctly execute.\nDeleting transferred file.\n" );
	}
	elsif ( $success == 1 ) {
		print "Indexing completed\n";
	}
	elsif ( $success == 2 ) {
		print "AutoFAIndex could not determine if the database was correctly indexed\n";
	}
}

sub errorHandler {
	my ( $message ) = @_;
	print "$message\n";
	my @filelist = <old*>;
	foreach my $file (@filelist){
		my @file_split = split /\./, $file;
		my $file_split_parts = $#file_split;
		my $new_filename = "";
		for (my $j = 1; $j <=$file_split_parts; $j++){
			if ($j == 1){
				$new_filename = $new_filename . $file_split[$j];
			}
			else {
				$new_filename = $new_filename . "." . $file_split[$j];
			}
			
		}
		print "$new_filename database files recovered\n";
		rename ($file, $new_filename);
	}   
	print "Aborting file transfer\n";
	exit;
}

sub printFileSize {
	my ( $str, $size ) = @_;
	print $str;
	printf ( "%.0f bytes ", $size );
	printf ( "(%.2f GBytes)\n", $size / 1000000000 );
}
