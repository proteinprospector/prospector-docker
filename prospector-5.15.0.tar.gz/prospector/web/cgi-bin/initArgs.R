myArgs <- commandArgs ();
len <- length ( myArgs );
dataFileName <- myArgs [len-1];
unix <- substr ( dataFileName, 1, 1 )  == '/';
versionMajor <- as.integer ( version$major );
versionMinor <- as.double ( version$minor );
imageFileName <- myArgs [len];
nch <- nchar ( imageFileName );
type <- substr ( imageFileName, nch - 2, nch );
