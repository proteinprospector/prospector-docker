imageHeight <- 300;
imageWidth <- 900;
source ( "initArgs.R" );
source ( "initGraph.R" );
band <- scan ( dataFileName, nmax=1 );
data <- read.table ( dataFileName, skip=1 );
plot (density (data[[1]],bw=band[1]),main="");
