#!/usr/bin/perl
##################################################################################
#
#  Filename   : automsviewer.pl
#
#  Created    : Nov 7th 2013
#
#  Purpose    : Command line program to batch process data sets for MS-Viewer
#
#  Author(s)  : Peter Baker
#
#  This file is the confidential and proprietary product of The Regents of
#  the University of California.
#
#  Copyright (2013-2015) The Regents of the University of California.
#
#  All rights reserved.
#
##################################################################################

use strict;
use XML::Simple;
use File::Basename;

my $osname = $^O;

{
	my $paramFile;
	my $resFName;
	my $pkFName;
	my $xmlParamsFlag = 0;
	if ( @ARGV > 0 ) {
		$paramFile = $ARGV[0];
		my($pFile, $pDir, $pExt) = fileparse ( $paramFile, , qr/\.[^.]*/ );
		if ( $pExt eq ".xml" ) {
			$xmlParamsFlag = 1;
		}
	}
	if ( @ARGV > 1 ) {
		$resFName = $ARGV[1];
	}
	if ( @ARGV > 2 ) {
		$pkFName = $ARGV[2];
	}
	my @resFiles = &getResFiles ( $resFName );

	my @pkFiles;
	if ( $pkFName ne "" ) {
		@pkFiles = &getPkFiles ( $pkFName );
	}

	my @paramFiles;
	if ( $xmlParamsFlag == 0 ) {
		@paramFiles = &getParamFiles ( $paramFile );
	}
	for ( my $i = 0; $i < @resFiles; $i++ ) {
		my $rp = $resFiles [$i];
		my $pp;
		if ( @pkFiles > 0 ) {
			$pp = $pkFiles [$i];
		}
		my $pf = $paramFile;
		if ( @paramFiles > 0 ) {
			$pf = $paramFiles [$i];
		}
		&runMSViewerCommand ( $rp, $pp, $pf );
	}

}
sub getResFiles {
	my ($resFName) = @_;
	my @resFiles;
	if ( -d $resFName ) {	#The results file name is a directory
		opendir ( DIR, $resFName ) || die "Cannot find directory $resFName\n";
		@resFiles = sort(grep(!/^(\.|\.\.)$/, readdir(DIR)));
		for ( my $i = 0; $i < @resFiles ; $i++ ) {
			$resFiles [$i] = $resFName . "/" . $resFiles [$i];
		}
		close DIR;
	}
	else {
		if ( open ( FILE, $resFName ) == 0 ) {
			errorHandler ( "Can't find the results list file" );
		}
		while ( my $line = <FILE> ) {
			$line =~ s/\015?\012?$//;
			push ( @resFiles, $line );
		}
		close FILE;
	}
	return ( @resFiles );
}
sub getPkFiles {
	my ($pkFName) = @_;
	my @pkFiles;
	if ( -d $pkFName ) {	#The pk file name is a directory
		opendir ( DIR, $pkFName ) || die "Cannot find directory $pkFName\n";
		@pkFiles = sort(grep(!/^(\.|\.\.)$/, readdir(DIR)));
		for ( my $i = 0; $i < @pkFiles ; $i++ ) {
			$pkFiles [$i] = $pkFName . "/" . $pkFiles [$i];
		}
		close DIR;
	}
	else {
		if ( open ( FILE, $pkFName ) == 0 ) {
			errorHandler ( "Can't find the peak list file" );
		}
		while ( my $line = <FILE> ) {
			$line =~ s/\015?\012?$//;
			push ( @pkFiles, $line );
		}
		close FILE;
	}
	return ( @pkFiles );
}
sub getParamFiles {
	my ($paramFile) = @_;
	my @paramFiles;
	if ( open ( FILE, $paramFile ) == 0 ) {
		errorHandler ( "Can't find the param file" );
	}
	while ( my $line = <FILE> ) {
		$line =~ s/\015?\012?$//;
		push ( @paramFiles, $line );
	}
	close FILE;
	return ( @paramFiles );
}
sub runMSViewerCommand {
	my ($resFilepath,$pkFilepath,$paramFilename) = @_;
	my $tempFilename = "viewer_$$.txt";
	my $mycommandline = "mssearch.cgi";

	print "Issuing MS-Viewer command.\n";
	if ( $osname eq "linux" ) {
		$mycommandline = "./mssearch.cgi"
	}
	$mycommandline .= " -f ../params/msviewer/default.xml";

	my $parameters = XMLin( $paramFilename );
	foreach my $key (keys %{$parameters}) {
		if ( ref $parameters->{$key} eq 'ARRAY' ) {
			my @pList;
			@pList = @{$parameters->{$key}};
			for ( my $i = 0; $i < @pList ; $i++ ) {
				$mycommandline .= " " . $key . "=" . $pList [$i];
			}
		}
		else {
			$mycommandline .= " " . $key . "=" . $parameters->{$key};
		}
	}

	$mycommandline .= " cl_results_filepath=$resFilepath";
	if ( $pkFilepath ne "" ) {
		$mycommandline .= " cl_peak_list_filepath=$pkFilepath";
	}

	$mycommandline .= " > " . $tempFilename;
	my $rc = system ( "$mycommandline" );
	if ( $rc ) {
		print "Command line = $mycommandline\n";
		print "Error Code = $rc\n";
		errorHandler ( "MS-Viewer did not correctly execute\n" );
	}
	unlink $tempFilename;
}
sub errorHandler {
	my ( $message ) = @_;
	print "$message\n";

	print "Aborting\n";
	exit;
}
