// ##################################################################
//
//	Filename:	info.js
//	Purpose:	JavaScript which assigns values used in Protein Prospector HTML forms.
//	Author(s):	Peter Baker
//	Created:	April 9, 1998
//
//	This file is the confidential and proprietary product of The Regents of
//	the University of California.
//
//	Copyright (1998-2008) The Regents of the University of California.
//
//	All rights reserved.
//
// ##################################################################
//
var date = new Date ();
var endYear = date.getFullYear ();

var binDir = "../cgi-bin";
var msparams = "params";
var msparamsDir = msparams + "/";

var pubWebServer = true;		// FA-Index is not an option for a public web server
var batchMSMSSearching = true;	// Many options are disabled if Batch MSMS Searching is not available
var sciexAnalystRawData = false;	// Sciex Analyst raw data supported
var ABITOFTOFRawData = false;	// ABI TOFTOF raw data supported
var ucsfBanner = true;
var copyrightHolders = "The Regents of the University of California";
var feedbackEmail = "ppadmin@cgl.ucsf.edu";
var ucsfHome = "http://msf.ucsf.edu";
var prospectorHome = "../mshome.htm";
//
// ############################################################################
// --->--->--->--->--->    D A T A B A S E   L I N K S    <---<---<---<---<---
// ############################################################################
//
// dbEST
//
function dbESTHumanFtpDirLink ()
{
	document.writeln ( "dbEST Human".link ("ftp://ftp.ncbi.nih.gov/blast/db/FASTA"));
	document.writeln ( "(ftp.ncbi.nih.gov/blast/db/FASTA/est_human.gz)" );
}
function dbESTMouseFtpDirLink ()
{
	document.writeln ( "dbEST Mouse".link ("ftp://ftp.ncbi.nih.gov/blast/db/FASTA"));
	document.writeln ( "(ftp.ncbi.nih.gov/blast/db/FASTA/est_mouse.gz)" );
}
function dbESTOthersFtpDirLink ()
{
	document.writeln ( "dbEST Others".link ("ftp://ftp.ncbi.nih.gov/blast/db/FASTA"));
	document.writeln ( "(ftp.ncbi.nih.gov/blast/db/FASTA/est_others.gz)" );
}
//
// Genpept
//
function GenpeptFtpDirLink ()
{
	document.writeln ( "Genbank".link ("ftp://ftp.ncbi.nih.gov/genbank"));
	document.writeln ( "(ftp.ncbi.nih.gov/genbank/relxxx.fsa_aa.gz)" );
}
//
// Ludwignr
//
function LudwignrFtpDirLink ()
{
	document.writeln ( "Ludwignr".link ("ftp://ftp.ch.embnet.org/pub/databases/nr_prot"));
	document.writeln ( "(all .seq files in this directory)" );
}
//
// NCBInr
//
function NCBInrFtpDirLink ()
{
	document.writeln ( "NCBI non-redundant".link ("ftp://ftp.ncbi.nih.gov/blast/db/FASTA"));
	document.writeln ( "(ftp.ncbi.nih.gov/blast/db/FASTA/nr.gz)" );
}
//
// Owl
//
function OwlFtpDirLink ()
{
	document.writeln ( "Owl".link ("ftp://ftp.ncbi.nih.gov/repository/OWL"));
	document.writeln ( "(ftp.ncbi.nih.gov/repository/OWL/owl.fasta.Z)" );
}
//
// Swiss Prot
//
function SwissProtFtpDirLink ()
{
	document.writeln ( "Swiss Prot".link ("ftp://ftp.ncbi.nih.gov/blast/db/FASTA"));
	document.writeln ( "(ftp.ncbi.nih.gov/blast/db/FASTA/swissprot.gz)" );
}
//
// UniProtKB
//
function UniprotFtpDirLink ()
{
	document.writeln ( "UniProtKB".link ("ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase"));
	document.writeln ( "(uniprot_sprot.fasta.gz and uniprot_trembl.fasta.gz)" );
}
// ############################################################################
// --->--->--->--->--->--->  T A G   M A N   L I N K  <---<---<---<---<---<---
// ############################################################################
function tagManLink ()
{
	document.writeln ( "MS-Tag".link ( "../../cgi-bin/msform.cgi?form=mstagstandard" ) );
}
// ############################################################################
// --->--->--->--->--->  F A I N D E X   M A N   L I N K  <---<---<---<---<---
// ############################################################################
function faindexManLink ()
{
	if ( pubWebServer )	document.writeln ( "FA-Index" );
	else				document.writeln ( "FA-Index".link ( "../../cgi-bin/msform.cgi?form=faindex" ) );
}
// ############################################################################
// --->--->--->--->--->--->  F A I N D E X   L I N K  <---<---<---<---<---<---
// ############################################################################
function faindexLink ()
{
	if ( !pubWebServer )	{
		document.writeln ( "<th bgcolor=\"#DDDDDD\" nowrap=\"nowrap\">" );
		document.writeln ( "<a href=\"cgi-bin/msform.cgi?form=faindex\">FA-Index</a>" );
		document.writeln ( "</th>" );
	}
}
// ############################################################################
// --->--->--->--->--->  B A T C H   M S M S   L I N K S  <---<---<---<---<---
// ############################################################################
function batchMSMSLinks ()
{
	if ( batchMSMSSearching )	{
		document.writeln ( "<div class=\"header3\">Batch MSMS Database Searching" );
		document.writeln ( "&nbsp;&nbsp;&nbsp;");
		document.writeln ( "Instructions".link ("html/instruct/batchtagman.htm") );
		document.writeln ( "</div>" );
		document.writeln ( "<table cellspacing=\"3\" cellpadding=\"3\">" );
		document.writeln ( "\t<tr>" );
		document.writeln ( "\t<th bgcolor=\"#FFDD99\" nowrap=\"nowrap\">" );
		document.writeln ( "\t\t<a href=\"cgi-bin/msform.cgi?form=search_compare&select_project=1\">Search Compare</a>" );
		document.writeln ( "\t</th>" );
		document.writeln ( "\t<th bgcolor=\"#FFDD99\" nowrap=\"nowrap\">" );
		document.writeln ( "\t\t<a href=\"cgi-bin/msform.cgi?form=batchtagweb\">Batch-Tag Web</a>" );
		document.writeln ( "\t</th>" );
		document.writeln ( "\t<th bgcolor=\"#FFDD99\" nowrap=\"nowrap\">" );
		document.writeln ( "\t\t<a href=\"cgi-bin/msform.cgi?form=batchtag&select_project=1\">Batch-Tag</a>" );
		document.writeln ( "\t</th>" );
		document.writeln ( "\t</tr>" );
		document.writeln ( "</table>" );
		document.writeln ( "<table cellspacing=\"3\" cellpadding=\"3\">" );
		document.writeln ( "\t<tr>" );
		document.writeln ( "\t<th bgcolor=\"#FFDD99\" nowrap=\"nowrap\">" );
		document.writeln ( "\t\t<a href=\"cgi-bin/msform.cgi?form=results_management&select_project=1\">Results Management</a>" );
		document.writeln ( "\t</th>" );
		document.writeln ( "\t<th bgcolor=\"#FFDD99\" nowrap=\"nowrap\">" );
		document.writeln ( "\t\t<a href=\"cgi-bin/msform.cgi?form=search_table\">Search Table</a>" );
		document.writeln ( "\t</th>" );
		if ( ABITOFTOFRawData )	{
			document.writeln ( "\t<th bgcolor=\"#FFDD99\" nowrap=\"nowrap\">" );
			document.writeln ( "\t\t<a href=\"html/peakSpotter.htm\">Peak Spotter</a>" );
			document.writeln ( "\t</th>" );
		}
		document.writeln ( "\t</tr>" );
		document.writeln ( "</table>" );
	}
}
// ############################################################################
// --->--->--->--->--->---> W I F F R E A D   L I N K <---<---<---<---<---<---
// ############################################################################
function wiffreadLink ()
{
	if ( sciexAnalystRawData )	{
		document.writeln ( "<th bgcolor=\"#FFDD99\" nowrap=\"nowrap\">" );
		document.writeln ( "<a href=\"html/wiffread.htm\">Wiff Read</a>" );
		document.writeln ( "</th>" );
	}
}
// ############################################################################
// --->--->  P R O G R A M   W E B   P A G E   C O P Y R I G H T  <---<---<---
// ############################################################################
function programWebPageCopyright ( startYear )
{
	years = ( startYear == endYear ) ? endYear : startYear + "-" + endYear;

	document.writeln ( "<div id=\"footer\">" );
	document.writeln ( "This program is the confidential and proprietary product of " + copyrightHolders + "." );
	document.writeln ( "Any unauthorized reproduction or transfer of this program is strictly prohibited." );
	document.writeln ( "<br />" );
	document.writeln ( "&#169; Copyright (" + years + ") " + copyrightHolders + "." );
	document.writeln ( "All rights reserved." );
	document.writeln ( "</div>" );
}
// ############################################################################
// --->--->   M A N U A L   W E B   P A G E   C O P Y R I G H T   <---<---<---
// ############################################################################
function manualWebPageCopyright ( startYear )
{
	years = ( startYear == endYear ) ? endYear : startYear + "-" + endYear;

	document.writeln ( "<div id=\"footer\">" );
	document.writeln ( "This file is the confidential and proprietary product of " + copyrightHolders + "." );
	document.writeln ( "Any unauthorized use, reproduction or transfer of this file is strictly prohibited." );
	document.writeln ( "<br />" );
	document.writeln ( "&#169; Copyright (" + years + ") " + copyrightHolders + "." );
	document.writeln ( "All rights reserved." );
	document.writeln ( "</div>" );
}
// ############################################################################
// --->--->---> H O M E   W E B   P A G E   C O P Y R I G H T <---<---<---<---
// ############################################################################
function homeWebPageCopyright ( startYear )
{
	years = ( startYear == endYear ) ? endYear : startYear + "-" + endYear;

	document.writeln ( "<div id=\"footer\">" );
	document.writeln ( "These programs are the confidential and proprietary product of " + copyrightHolders + "." );
	document.writeln ( "Any unauthorized reproduction or transfer of these programs is strictly prohibited." );
	document.writeln ( "<br />" );
	document.writeln ( "&#169; Copyright (" + years + ") " + copyrightHolders + "." );
	document.writeln ( "All rights reserved." );
	document.writeln ( "</div>" );
}
// ############################################################################
// --->--->--->--->--->--->    F E E D B A C K    <---<---<---<---<---<---<---
// ############################################################################
function feedback ( emailAddress )
{
	document.writeln ( "Please give feedback, by sending e-mail to " );
	document.writeln ( "<a href=\"mailto:" + emailAddress + "\">" + emailAddress + "</a>" );
}
// ############################################################################
// --->--->--->--->--->    L A S T   R E V I S E D    <---<---<---<---<---<---
// ############################################################################
function lastRevised ()
{
	document.writeln ( "<br />" + "HTML page last revised: (" + document.lastModified + ")" + "<br />" );
}
// ############################################################################
// --->--->--->---> P O S T   M U L T I P A R T   F O R M <---<---<---<---<---
// ############################################################################
function postMultipartForm ( directory, file )
{
	document.writeln ( "<form method=\"POST\" action=\"" + directory + "/" + file + "\" enctype=\"multipart/form-data\">" );
}
// ############################################################################
// --->--->--->--->  B Y   R O B E R T   A N D   P E T E  <---<---<---<---<---
// ############################################################################
function byRobertAndPete ()
{
	document.writeln ( "(by Robert Chalkley and Peter Baker)" );
}
// ############################################################################
// --->--->--->--->  F E E D B A C K   M A I L   L I N K  <---<---<---<---<---
// ############################################################################
function feedbackMailLink ()
{
	document.write ( feedbackEmail.link ( "mailto:" + feedbackEmail ) );
}
// ############################################################################
// --->--->--->--->    D I S P L A Y   M S P A R A M S    <---<---<---<---<---
// ############################################################################
function displayMsparams ()
{
	document.write ( msparams );
}
// ############################################################################
// --->--->--->    D I S P L A Y   M S P A R A M S   D I R    <---<---<---<---
// ############################################################################
function displayMsparamsDir ()
{
	document.write ( msparamsDir );
}
// ############################################################################
// --->--->--->    D I S P L A Y   M A N U A L   L I N K S    <---<---<---<---
// ############################################################################
function displayManualLinks ()
{
	document.writeln ( "<div id=\"header\">" );
	document.writeln ( "Home".link ("../../mshome.htm") );
	document.writeln ( "| " + "General".link ("allman.htm") );
	document.writeln ( "| " + "Server Admin".link ("servadmn.htm") );
	document.writeln ( "| " + "FA-Index".link ("faman.htm") );
	document.writeln ( "| " + "DB-Stat".link ("dbstatman.htm") );
	document.writeln ( "| " + "Batch MSMS Searching".link ("batchtagman.htm") );
	document.writeln ( "<br />" );

	document.writeln ( "MS-Fit".link ("fitman.htm") );
	document.writeln ( "| " + "MS-Tag".link ("tagman.htm") );
	document.writeln ( "| " + "MS-Seq".link ("seqman.htm") );
	document.writeln ( "| " + "MS-Pattern".link ("patternman.htm") );
	document.writeln ( "| " + "MS-Homology".link ("homologyman.htm") );
	document.writeln ( "| " + "MS-Digest".link ("digestman.htm") );
	document.writeln ( "| " + "MS-Bridge".link ("bridgeman.htm") );
	document.writeln ( "| " + "MS-NonSpecific".link ("nonspecificman.htm") );
	document.writeln ( "| " + "MS-Product".link ("prodman.htm") );
	document.writeln ( "| " + "MS-Comp".link ("compman.htm") );
	document.writeln ( "| " + "MS-Isotope".link ("isoman.htm") );
	document.writeln ( "| " + "MS-Viewer".link ("viewerman.htm") );

	document.writeln ( "</div>" );
}
// ############################################################################
// --->--->---> D I S P L A Y   R E F E R E N C E   L I N K S <---<---<---<---
// ############################################################################
function displayReferenceLinks ()
{
	document.writeln ( "<div id=\"header\">" );
	document.writeln ( "Home".link ("../../mshome.htm") );
	document.writeln ( "| " + "Mutation Mass Shifts".link ("mutation.htm") );
	document.writeln ( "| " + "Dipeptide Masses".link ("dipep.htm") );
	document.writeln ( "| " + "Trypsin Autolysis Products".link ("trypsin.htm") );
	document.writeln ( "</div>" );
}
function displayHomeLink ( toHome )
{
	document.writeln ( "<div id=\"header\">" );
	document.writeln ( "Home".link ( toHome + "mshome.htm") );
	document.writeln ( "</div>" );
}
function displayHeadngnorm ( imageDir )
{
	if ( ucsfBanner ) {
		document.writeln ( "<div id=\"headngnorm\">" );
		document.writeln ( "<img src=\"" + imageDir + "images/bannerblack.gif\" border=\"0\" usemap=\"#UCSF\">" );
		document.writeln ( "<map name=\"UCSF\" id=\"UCSF\">" );
		document.writeln ( "<area target=\"_blank\" shape=\"rect\" coords=\"89,6,291,23\" href=\"http://www.ucsf.edu\" alt=\"University of California, San Francisco\">" );
		document.writeln ( "<area target=\"_blank\" shape=\"rect\" coords=\"303,6,371,23\" href=\"http://www.ucsf.edu/about_ucsf\" alt=\"About UCSF\">" );
		document.writeln ( "<area target=\"_blank\" shape=\"rect\" coords=\"381,6,458,23\" href=\"http://www.google.com/u/ucsf\" alt=\"Search UCSF\">" );
		document.writeln ( "<area target=\"_blank\" shape=\"rect\" coords=\"470,6,594,23\" href=\"http://www.ucsfhealth.org/\" alt=\"UCSF  medical center\">" );
		document.writeln ( "</map>" );
		document.writeln ( "</div>" );
	}
}
