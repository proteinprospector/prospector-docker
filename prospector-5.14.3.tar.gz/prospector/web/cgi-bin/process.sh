#!/bin/bash

FILES="NCBInr.2008.06.16
SwissProt.2008.06.10
SwissProt.2008.06.10.random.concat
UniProtKB.2008.06.10
UniProtKB.2008.06.10.random.concat"

for file in ${FILES}; do
	echo ${file}
	./faindex.cgi - database=${file} create_database_indicies=1
done
