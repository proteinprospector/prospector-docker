if ( type == "pdf" ) {
	bgColor <- 'white';
	pdf (imageFileName);
}
if ( type == "png" ) {
	bgColor <- 'white';
	unitsArg <- versionMajor > 2 || ( versionMajor == 2 && versionMinor >= 6.0 );
	if ( unix ) {
		resolution <- 72;
		if ( unitsArg ) {
			bitmap (imageFileName, type="pngalpha", imageHeight/resolution, imageWidth/resolution, resolution, units="in", 12 );
		}
		else {
			bitmap (imageFileName, type="pngalpha", imageHeight/resolution, imageWidth/resolution, resolution, 12 );
		}
	}
	else {
		if ( unitsArg ) {
			png (imageFileName, imageWidth, imageHeight, units="px", 12 );
		}
		else {
			png (imageFileName, imageWidth, imageHeight, 8);
		}
	}
}
par(bg=bgColor,font=2,mar=c(4,4,1,1),mgp=c(2.7,0.7,0),las=1);
