#!/usr/bin/perl
local $ENV{"HOME"} = "/var/www";

$SIG{TERM} = \&caughtSignalTerm;

my $key = $ARGV[0];

my $command = "/var/lib/prospector/web/cgi-bin/mssearch.cgi";

my $x = $command . " -k " . $key;
my $temp_file = "/tmp/" . $key;

system ( $x . " > " . $temp_file );

unlink ( $temp_file );

sub caughtSignalTerm {
	my $cmd = "ps -ef | grep \"mssearch.cgi -k " . $key . "\" | grep -v \"sh -c\" | grep -v \"grep \" | awk '{print \$2}'";
	my $pid = `$cmd`;
	kill 9, $pid;
	unlink ( $temp_file );
	exit ( 0 );
}
