#!/usr/bin/perl

use Mail::Sendmail;
my $smtp = 'durer.ucsf.edu';
unshift @{$Mail::Sendmail::mailcfg{'smtp'}}, $smtp;

my $to		= $ARGV[0];
my $id		= $ARGV[1];
my $project	= $ARGV[2];
my $results	= $ARGV[3];
my $status	= $ARGV[4];
my $url		= $ARGV[5];

my $from = 'prospector-results@msf.ucsf.edu';
my $reply_to = 'ppadmin@cgl.ucsf.edu';

my %email = ();
my $message = "";
my $subject = "";

if ( $status eq "done" ) {
	$message  = "Your search on Protein Prospector has completed.\n\n";
	$message .= "Search number: $id\n";
	$message .= "Project: $project\n";
	$message .= "Results: $results\n\n";
	$message .= "You may view the search results by visiting this link:\n\n";
	$message .= $url . "\n\n";
#	$message .= "These results will be kept on our server for at least 60 days.\n";
#	$message .= "After that, the files may be deleted without notice.\n\n";
	$message .= "Please keep this email for future reference.\n\n";

	$subject = "Your Protein Prospector search $id is complete";
}
else {
	$message  = "Your search on Protein Prospector has failed to complete.\n\n";
	$message .= "Search number: $id\n";
	$message .= "Project: $project\n";
	$message .= "Results: $results\n\n";
	$message .= "You may view the status information by visiting this link:\n\n";
	$message .= $url . "\n\n";

	$subject = "Your Protein Prospector search $id has failed to complete.";
}

$email{To} = $to;
$email{From} = $from;
$email{"Reply-To"} = $reply_to;
$email{Subject} = $subject;
$email{Message} = $message;
#$email{smtp} = $smtp;

Mail::Sendmail::sendmail( %email );
